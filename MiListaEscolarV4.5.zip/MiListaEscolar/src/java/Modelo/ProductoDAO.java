/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Modelo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

public class ProductoDAO {
    
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    public List listar(){
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM productos";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while (rs.next()) {
               Producto p = new Producto();
               p.setId(rs.getInt("id"));
               p.setNombre(rs.getString("nombre"));
               p.setCategoria(rs.getString("categoria"));
               p.setPrecio(rs.getDouble("precio"));
               p.setStock(rs.getInt("stock"));
               p.setDescripcion(rs.getString("descripcion"));
               p.setFoto(rs.getBinaryStream("foto"));
               lista.add(p);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar productos: " + e.getMessage());
            e.printStackTrace();
        }
        return lista;
    }
    
   public Producto list(int id){
    String sql = "SELECT * FROM productos WHERE id=?";
    Producto p = new Producto();
    try {
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        ps.setInt(1, id);
        rs = ps.executeQuery();
        while (rs.next()) {
           p.setId(rs.getInt("id"));
           p.setNombre(rs.getString("nombre"));
           p.setCategoria(rs.getString("categoria"));
           p.setPrecio(rs.getDouble("precio"));
           p.setStock(rs.getInt("stock"));
           p.setDescripcion(rs.getString("descripcion"));
           p.setFoto(rs.getBinaryStream("foto"));
        }
    } catch (SQLException e) {
        System.err.println("Error al listar producto: " + e.getMessage());
        e.printStackTrace();
    }
    return p;
}
    
    public List<String> listarCategorias() {
    List<String> categorias = new ArrayList<>();
    String sql = "SELECT DISTINCT categoria FROM productos";
    try {
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        rs = ps.executeQuery();
        
        while (rs.next()) {
            categorias.add(rs.getString("categoria"));
        }
    } catch (SQLException e) {
        System.err.println("Error al listar categorías: " + e.getMessage());
        e.printStackTrace();
    }
    return categorias;
}

public List<Producto> listarPorCategoria(String categoria) {
    List<Producto> lista = new ArrayList<>();
    String sql = "SELECT * FROM productos WHERE categoria=?";
    try {
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        ps.setString(1, categoria);
        rs = ps.executeQuery();
        
        while (rs.next()) {
           Producto p = new Producto();
           p.setId(rs.getInt("id"));
           p.setNombre(rs.getString("nombre"));
           p.setCategoria(rs.getString("categoria"));
           p.setPrecio(rs.getDouble("precio"));
           p.setStock(rs.getInt("stock"));
           p.setDescripcion(rs.getString("descripcion"));
           p.setFoto(rs.getBinaryStream("foto"));
           lista.add(p);
        }
    } catch (SQLException e) {
        System.err.println("Error al listar productos por categoría: " + e.getMessage());
        e.printStackTrace();
    }
    return lista;
}
    
    
    public void listarimg(int id, HttpServletResponse response) {
    String sql = "SELECT foto FROM productos WHERE id=?";
    InputStream inputStream = null;
    OutputStream outputStream = null;
    BufferedInputStream bufferedInputStream = null;
    BufferedOutputStream bufferedOutputStream = null;
    
    try {
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        ps.setInt(1, id);
        rs = ps.executeQuery();
        
        if (rs.next()) {
            inputStream = rs.getBinaryStream("foto");
            if (inputStream != null) {
                response.setContentType("image/*");
                outputStream = response.getOutputStream();
                
                bufferedInputStream = new BufferedInputStream(inputStream);
                bufferedOutputStream = new BufferedOutputStream(outputStream);
                
                byte[] buffer = new byte[4096];
                int bytesRead;
                
                while ((bytesRead = bufferedInputStream.read(buffer)) != -1) {
                    bufferedOutputStream.write(buffer, 0, bytesRead);
                }
            } else {
            }
        }
    } catch (Exception e) {
        System.err.println("Error al mostrar imagen: " + e.getMessage());
        e.printStackTrace();
    } finally {
        // Cerrar todos los recursos en orden inverso a su creación
        try {
            if (bufferedInputStream != null) bufferedInputStream.close();
            if (bufferedOutputStream != null) bufferedOutputStream.close();
            if (inputStream != null) inputStream.close();
            if (outputStream != null) outputStream.close();
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (IOException | SQLException ex) {
            System.err.println("Error al cerrar recursos: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
 }

    
    public boolean agregar(Producto p){
        String sql = "INSERT INTO productos (nombre, categoria, precio, stock, descripcion, foto) VALUES(?,?,?,?,?,?)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getCategoria());
            ps.setDouble(3, p.getPrecio());
            ps.setInt(4, p.getStock());
            ps.setString(5, p.getDescripcion());
            ps.setBlob(6, p.getFoto());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.err.println("Error al agregar producto: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean actualizar(Producto p) {
        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            con = cn.getConnection();
            
            if (p.getFoto() != null) {
                String sql = "UPDATE productos SET nombre=?, categoria=?, precio=?, stock=?, descripcion=?, foto=? WHERE id=?";
                ps = con.prepareStatement(sql);
                ps.setString(1, p.getNombre());
                ps.setString(2, p.getCategoria());
                ps.setDouble(3, p.getPrecio());
                ps.setInt(4, p.getStock());
                ps.setString(5, p.getDescripcion());
                ps.setBlob(6, p.getFoto());
                ps.setInt(7, p.getId());
            } else {
                String sql = "UPDATE productos SET nombre=?, categoria=?, precio=?, stock=?, descripcion=? WHERE id=?";
                ps = con.prepareStatement(sql);
                ps.setString(1, p.getNombre());
                ps.setString(2, p.getCategoria());
                ps.setDouble(3, p.getPrecio());
                ps.setInt(4, p.getStock());
                ps.setString(5, p.getDescripcion());
                ps.setInt(6, p.getId());
            }
            
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al actualizar producto: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
        
    public boolean delete(int id) {
        String sql = "DELETE FROM productos WHERE id=?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al eliminar producto: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}
