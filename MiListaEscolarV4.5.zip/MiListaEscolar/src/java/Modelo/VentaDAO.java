/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class VentaDAO {
    private Conexion cn = new Conexion();
    private Connection con;
    private PreparedStatement ps;
    private ResultSet rs;
    private ProductoDAO productoDAO = new ProductoDAO();

    // Método para registrar una nueva venta y sus detalles
    public int registrarVenta(Venta venta, List<CarritoItem> carritoItems) {
        int idVenta = -1;
        String sqlVenta = "INSERT INTO ventas (id_usuario, fecha_venta, metodo_pago, total) VALUES (?, NOW(), ?, ?)";
        String sqlDetalle = "INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
        String sqlActualizarStock = "UPDATE productos SET stock = stock - ? WHERE id = ?";
        
        try {
            con = cn.getConnection();
            con.setAutoCommit(false); // Iniciar transacción
            
            // 1. Registrar la venta principal
            ps = con.prepareStatement(sqlVenta, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, venta.getIdUsuario());
            ps.setString(2, venta.getMetodoPago());
            ps.setDouble(3, venta.getTotal());
            ps.executeUpdate();
            
            // Obtener el ID generado
            rs = ps.getGeneratedKeys();
            if (rs.next()) {
                idVenta = rs.getInt(1);
            } else {
                throw new SQLException("No se pudo obtener el ID de la venta");
            }
            
            // 2. Registrar los detalles de la venta
            ps = con.prepareStatement(sqlDetalle);
            for (CarritoItem item : carritoItems) {
                ps.setInt(1, idVenta);
                ps.setInt(2, item.getProducto().getId());
                ps.setInt(3, item.getCantidad());
                ps.setDouble(4, item.getProducto().getPrecio());
                ps.addBatch();
            }
            ps.executeBatch();
            
            // 3. Actualizar el stock de productos
            ps = con.prepareStatement(sqlActualizarStock);
            for (CarritoItem item : carritoItems) {
                ps.setInt(1, item.getCantidad());
                ps.setInt(2, item.getProducto().getId());
                ps.addBatch();
            }
            ps.executeBatch();
            
            con.commit(); // Confirmar transacción
            return idVenta;
            
        } catch (SQLException e) {
            try {
                if (con != null) {
                    con.rollback(); // Revertir en caso de error
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return -1;
        } finally {
            cerrarRecursos();
        }
    }
    
    // Método para obtener una venta por su ID
    public Venta obtenerVentaPorId(int idVenta) {
        Venta venta = null;
        String sql = "SELECT * FROM ventas WHERE id = ?";
        
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, idVenta);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                venta = new Venta();
                venta.setId(rs.getInt("id"));
                venta.setIdUsuario(rs.getInt("id_usuario"));
                venta.setFechaVenta(rs.getTimestamp("fecha_venta"));
                venta.setMetodoPago(rs.getString("metodo_pago"));
                venta.setTotal(rs.getDouble("total"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            cerrarRecursos();
        }
        return venta;
    }
    
    // Método para listar los detalles de una venta
    public List<DetalleVenta> listarDetallesVenta(int idVenta) {
        List<DetalleVenta> detalles = new ArrayList<>();
        String sql = "SELECT dv.*, p.nombre, p.categoria, p.descripcion " +
                     "FROM detalle_venta dv " +
                     "JOIN productos p ON dv.id_producto = p.id " +
                     "WHERE dv.id_venta = ?";
        
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, idVenta);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                DetalleVenta detalle = new DetalleVenta();
                detalle.setId(rs.getInt("id"));
                detalle.setIdVenta(rs.getInt("id_venta"));
                
                // Crear objeto Producto
                Producto producto = new Producto();
                producto.setId(rs.getInt("id_producto"));
                producto.setNombre(rs.getString("nombre"));
                producto.setCategoria(rs.getString("categoria"));
                producto.setDescripcion(rs.getString("descripcion"));
                producto.setPrecio(rs.getDouble("precio_unitario"));
                
                detalle.setProducto(producto);
                detalle.setCantidad(rs.getInt("cantidad"));
                detalle.setPrecioUnitario(rs.getDouble("precio_unitario"));
                
                detalles.add(detalle);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            cerrarRecursos();
        }
        return detalles;
    }
    
    // Método para listar todas las ventas de un usuario
    public List<Venta> listarVentasPorUsuario(int idUsuario) {
        List<Venta> ventas = new ArrayList<>();
        String sql = "SELECT * FROM ventas WHERE id_usuario = ? ORDER BY fecha_venta DESC";
        
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, idUsuario);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                Venta venta = new Venta();
                venta.setId(rs.getInt("id"));
                venta.setIdUsuario(rs.getInt("id_usuario"));
                venta.setFechaVenta(rs.getTimestamp("fecha_venta"));
                venta.setMetodoPago(rs.getString("metodo_pago"));
                venta.setTotal(rs.getDouble("total"));
                
                ventas.add(venta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            cerrarRecursos();
        }
        return ventas;
    }
    
    // Método para cerrar recursos
    private void cerrarRecursos() {
        try { if (rs != null) rs.close(); } catch (Exception e) {}
        try { if (ps != null) ps.close(); } catch (Exception e) {}
        try { if (con != null) con.close(); } catch (Exception e) {}
    }
}