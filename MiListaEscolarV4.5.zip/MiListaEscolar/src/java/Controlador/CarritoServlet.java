/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controlador;

import Modelo.CarritoItem;
import Modelo.Producto;
import Modelo.ProductoDAO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "CarritoServlet", urlPatterns = {"/CarritoServlet"})
public class CarritoServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        
        // Obtener o crear el carrito en la sesión
        List<CarritoItem> carrito = (List<CarritoItem>) session.getAttribute("carritoItems");
        if (carrito == null) {
            carrito = new ArrayList<>();
            session.setAttribute("carritoItems", carrito);
        }
        
        ProductoDAO productoDAO = new ProductoDAO();
        
        try {
            switch (action) {
                case "agregar":
                    agregarProducto(request, response, carrito, productoDAO);
                    break;
                case "actualizar":
                    actualizarProducto(request, response, carrito);
                    break;
                case "eliminar":
                    eliminarProducto(request, response, carrito);
                    break;
                case "vaciar":
                    vaciarCarrito(request, response, session);
                    break;
                case "contarItems":
                    contarItems(request, response, session);
                    break;
                default:
                    response.sendRedirect("carrito.jsp");
            }
            
            // Calcular el total del carrito
            double total = calcularTotal(carrito);
            session.setAttribute("totalCarrito", total);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("carrito.jsp?error=Ocurrió un error al procesar la solicitud");
        }
    }
    
    private void agregarProducto(HttpServletRequest request, HttpServletResponse response, 
            List<CarritoItem> carrito, ProductoDAO productoDAO) throws IOException {
        int idProducto = Integer.parseInt(request.getParameter("idProducto"));
        int cantidad = Integer.parseInt(request.getParameter("cantidad"));
        
        // Verificar si el producto ya está en el carrito
        boolean productoExistente = false;
        for (CarritoItem item : carrito) {
            if (item.getProducto().getId() == idProducto) {
                // Actualizar cantidad si el producto ya está en el carrito
                int nuevaCantidad = item.getCantidad() + cantidad;
                if (nuevaCantidad <= item.getProducto().getStock()) {
                    item.setCantidad(nuevaCantidad);
                    productoExistente = true;
                    break;
                } else {
                    response.sendRedirect("index.jsp?error=No hay suficiente stock disponible");
                    return;
                }
            }
        }
        
        if (!productoExistente) {
            // Agregar nuevo producto al carrito
            Producto producto = productoDAO.list(idProducto);
            if (producto != null && cantidad <= producto.getStock()) {
                int nuevoId = carrito.isEmpty() ? 1 : carrito.get(carrito.size() - 1).getId() + 1;
                carrito.add(new CarritoItem(nuevoId, producto, cantidad));
            } else {
                response.sendRedirect("index.jsp?error=No hay suficiente stock disponible");
                return;
            }
        }
        
        response.sendRedirect("index.jsp?success=Producto agregado al carrito");
    }
    
    private void actualizarProducto(HttpServletRequest request, HttpServletResponse response, 
            List<CarritoItem> carrito) throws IOException {
        int idItem = Integer.parseInt(request.getParameter("idItem"));
        int nuevaCantidad = Integer.parseInt(request.getParameter("cantidad"));
        
        for (CarritoItem item : carrito) {
            if (item.getId() == idItem) {
                if (nuevaCantidad <= item.getProducto().getStock()) {
                    item.setCantidad(nuevaCantidad);
                    response.sendRedirect("carrito.jsp?success=Cantidad actualizada");
                    return;
                } else {
                    response.sendRedirect("carrito.jsp?error=No hay suficiente stock disponible");
                    return;
                }
            }
        }
        
        response.sendRedirect("carrito.jsp?error=Producto no encontrado en el carrito");
    }
    
    private void eliminarProducto(HttpServletRequest request, HttpServletResponse response, 
            List<CarritoItem> carrito) throws IOException {
        int idItem = Integer.parseInt(request.getParameter("idItem"));
        
        for (int i = 0; i < carrito.size(); i++) {
            if (carrito.get(i).getId() == idItem) {
                carrito.remove(i);
                response.sendRedirect("carrito.jsp?success=Producto eliminado del carrito");
                return;
            }
        }
        
        response.sendRedirect("carrito.jsp?error=Producto no encontrado en el carrito");
    }
    
    private void vaciarCarrito(HttpServletRequest request, HttpServletResponse response, 
            HttpSession session) throws IOException {
        session.removeAttribute("carritoItems");
        session.removeAttribute("totalCarrito");
        response.sendRedirect("carrito.jsp?success=Carrito vaciado correctamente");
    }
    
    private double calcularTotal(List<CarritoItem> carrito) {
        return carrito.stream()
                .mapToDouble(CarritoItem::getSubtotal)
                .sum();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet para manejar el carrito de compras";
    }

    private void contarItems(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws IOException {
    List<CarritoItem> carrito = (List<CarritoItem>) session.getAttribute("carritoItems");
    int cantidad = carrito != null ? carrito.size() : 0;
    
    response.setContentType("application/json");
    response.getWriter().write("{\"cantidad\": " + cantidad + "}");
   }
}