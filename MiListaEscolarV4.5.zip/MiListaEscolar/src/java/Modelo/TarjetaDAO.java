/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author angel
 */
public class TarjetaDAO {
    
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
public List<Tarjeta> listarPorUsuario(int idUsuario) {
        List<Tarjeta> lista = new ArrayList<>();
        String sql = "SELECT * FROM tarjetas WHERE id_usuario = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, idUsuario);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                Tarjeta tarjeta = new Tarjeta();
                tarjeta.setId(rs.getInt("id"));
                tarjeta.setIdUsuario(rs.getInt("id_usuario"));
                tarjeta.setTipo(rs.getString("tipo"));
                tarjeta.setNumero(rs.getString("numero"));
                tarjeta.setNombreTitular(rs.getString("nombre_titular"));
                tarjeta.setFechaVencimiento(rs.getString("fecha_vencimiento"));
                tarjeta.setCvv(rs.getString("cvv"));
                tarjeta.setSaldo(rs.getDouble("saldo"));
                
                lista.add(tarjeta);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar tarjetas: " + e.getMessage());
        }
        return lista;
    }
    
    public boolean agregar(Tarjeta tarjeta) {
        String sql = "INSERT INTO tarjetas (id_usuario, tipo, numero, nombre_titular, fecha_vencimiento, cvv, saldo) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, tarjeta.getIdUsuario());
            ps.setString(2, tarjeta.getTipo());
            ps.setString(3, tarjeta.getNumero());
            ps.setString(4, tarjeta.getNombreTitular());
            ps.setString(5, tarjeta.getFechaVencimiento());
            ps.setString(6, tarjeta.getCvv());
            ps.setDouble(7, tarjeta.getSaldo());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al agregar tarjeta: " + e.getMessage());
            return false;
        }
    }
    
    public boolean actualizarSaldo(int idTarjeta, double nuevoSaldo) {
        String sql = "UPDATE tarjetas SET saldo = ? WHERE id = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setDouble(1, nuevoSaldo);
            ps.setInt(2, idTarjeta);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al actualizar saldo: " + e.getMessage());
            return false;
        }
    }
    
    // Método para inicializar tarjetas de prueba
    public void inicializarTarjetasPrueba(int idUsuario) {
        // Verificar si el usuario ya tiene tarjetas registradas
        if (!listarPorUsuario(idUsuario).isEmpty()) {
            return;
        }
        
        // Tarjeta Visa
        Tarjeta visa = new Tarjeta();
        visa.setIdUsuario(idUsuario);
        visa.setTipo("visa");
        visa.setNumero("4111111111111111");
        visa.setNombreTitular("TARJETA PRUEBA VISA");
        visa.setFechaVencimiento("12/2025");
        visa.setCvv("123");
        visa.setSaldo(1000.00);
        agregar(visa);
        
        // Tarjeta Mastercard
        Tarjeta mastercard = new Tarjeta();
        mastercard.setIdUsuario(idUsuario);
        mastercard.setTipo("mastercard");
        mastercard.setNumero("5555555555554444");
        mastercard.setNombreTitular("TARJETA PRUEBA MASTERCARD");
        mastercard.setFechaVencimiento("06/2026");
        mastercard.setCvv("456");
        mastercard.setSaldo(1500.00);
        agregar(mastercard);
        
        // Tarjeta American Express
        Tarjeta amex = new Tarjeta();
        amex.setIdUsuario(idUsuario);
        amex.setTipo("amex");
        amex.setNumero("378282246310005");
        amex.setNombreTitular("TARJETA PRUEBA AMEX");
        amex.setFechaVencimiento("09/2024");
        amex.setCvv("7890");
        amex.setSaldo(2000.00);
        agregar(amex);
    }
}
