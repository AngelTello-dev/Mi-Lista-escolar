/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controlador;

import Modelo.CarritoItem;
import Modelo.Tarjeta;
import Modelo.TarjetaDAO;
import Modelo.Venta;
import Modelo.VentaDAO;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "PagoServlet", urlPatterns = {"/PagoServlet"})
public class PagoServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        
        // Verificar sesión primero
        Integer idUsuario = (Integer) session.getAttribute("idUsuario");
        if (idUsuario == null) {
            response.sendRedirect("loginForm.jsp");
            return;
        }
        
        try {
            switch (action) {
                case "procesarPago":
                    procesarPago(request, response, session, idUsuario);
                    break;
                default:
                    response.sendRedirect("carrito.jsp");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("pago.jsp?error=Ocurrió un error al procesar el pago: " + e.getMessage());
        }
    }
    
    private void procesarPago(HttpServletRequest request, HttpServletResponse response, 
            HttpSession session, int idUsuario) throws IOException, ServletException {
        
        // Obtener datos del formulario
        String idTarjetaStr = request.getParameter("tarjeta");
        String metodoPago = request.getParameter("metodoPago");
        
        // Validar parámetros
        if (idTarjetaStr == null || idTarjetaStr.isEmpty() || metodoPago == null || metodoPago.isEmpty()) {
            response.sendRedirect("pago.jsp?error=Datos de pago incompletos");
            return;
        }
        
        int idTarjeta;
        try {
            idTarjeta = Integer.parseInt(idTarjetaStr);
        } catch (NumberFormatException e) {
            response.sendRedirect("pago.jsp?error=Tarjeta inválida");
            return;
        }
        
        // Obtener carrito de la sesión
        List<CarritoItem> carritoItems = (List<CarritoItem>) session.getAttribute("carritoItems");
        Double total = (Double) session.getAttribute("totalCarrito");
        
        if (carritoItems == null || carritoItems.isEmpty() || total == null) {
            response.sendRedirect("carrito.jsp?error=El carrito está vacío");
            return;
        }
        
        // Verificar saldo de la tarjeta
        TarjetaDAO tarjetaDAO = new TarjetaDAO();
        Tarjeta tarjeta = tarjetaDAO.listarPorUsuario(idUsuario).stream()
                .filter(t -> t.getId() == idTarjeta)
                .findFirst()
                .orElse(null);
        
        if (tarjeta == null) {
            response.sendRedirect("pago.jsp?error=Tarjeta no encontrada");
            return;
        }
        
        if (tarjeta.getSaldo() < total) {
            response.sendRedirect("pago.jsp?error=Saldo insuficiente en la tarjeta");
            return;
        }
        
        // Procesar la venta
        try {
            VentaDAO ventaDAO = new VentaDAO();
            Venta venta = new Venta();
            venta.setIdUsuario(idUsuario);
            venta.setMetodoPago(metodoPago);
            venta.setTotal(total);
            
            // Registrar la venta
            int idVenta = ventaDAO.registrarVenta(venta, carritoItems);
            
            if (idVenta > 0) {
                // Actualizar saldo de la tarjeta
                double nuevoSaldo = tarjeta.getSaldo() - total;
                tarjetaDAO.actualizarSaldo(idTarjeta, nuevoSaldo);
                
                // Limpiar carrito
                session.removeAttribute("carritoItems");
                session.removeAttribute("totalCarrito");
                
                // Redirigir a confirmación
                response.sendRedirect("confirmacion.jsp?idVenta=" + idVenta);
            } else {
                response.sendRedirect("pago.jsp?error=Error al registrar la venta");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("pago.jsp?error=Error en el servidor: " + e.getMessage());
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}